module com.devtony.railwayreservation {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.devtony.railwayreservation to javafx.fxml;
    exports com.devtony.railwayreservation;
}