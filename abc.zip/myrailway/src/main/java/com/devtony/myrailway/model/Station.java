// File Path: /home/tony/intellih/myrailway/src/main/java/com/devtony/myrailway/model/Station.java
package com.devtony.myrailway.model;

public class Station {
    private int stationId;
    private String stationName;
    private String stationCode;
    
    // Getters and setters
    public int getStationId() { return stationId; }
    public void setStationId(int stationId) { this.stationId = stationId; }
    public String getStationName() { return stationName; }
    public void setStationName(String stationName) { this.stationName = stationName; }
    public String getStationCode() { return stationCode; }
    public void setStationCode(String stationCode) { this.stationCode = stationCode; }
}
